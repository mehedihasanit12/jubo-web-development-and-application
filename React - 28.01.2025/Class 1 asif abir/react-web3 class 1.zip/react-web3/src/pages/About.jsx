import { Link } from "react-router";


const About = () => {
    return (
        <div>
            This is about page
            <Link to="/">Home</Link>
        </div>
    );
};

export default About;