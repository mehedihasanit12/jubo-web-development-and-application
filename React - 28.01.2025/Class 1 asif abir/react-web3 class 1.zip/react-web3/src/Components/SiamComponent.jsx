
const SiamComponent = ({data, carecter}) => {
    
    return (
        <div>
            {data} is not a {carecter} boy.
        </div>
    );
};


export default SiamComponent;