import { useEffect, useState } from "react";


const FetchData = () => {
    const [data, setData] = useState([]);
    useEffect(() => {
        fetch("https://jsonplaceholder.typicode.com/users")
            .then((response) => response.json())
            .then((res) => setData(res))
    });
    return (
      <div className="col-span-3 grid grid-cols-1 lg:grid-cols-3 gap-4">
        {data.map((item, index) => (
          <div key={index} className="border p-4 mb-3 rounded-2xl">
            <h1>
              <span className="font-semibold">Name:</span> {item.name}
            </h1>
            <h1>
              <span className="font-semibold">Email:</span> {item.email}
            </h1>
            <h1>
              <span className="font-semibold">Website:</span> {item.website}
            </h1>
          </div>
        ))}
      </div>
    );
};

export default FetchData;