import { Link } from "react-router";
import ChangeValue from "./Components/ChangeValue";
import FetchData from "./Components/FetchData";
import SiamComponent from "./Components/SiamComponent";

const App = () => {
  return (
    <div className="container mx-auto grid grid-cols-1 lg:grid-cols-3 gap-4 p-4">
      <div className="bordered bordder rounded-2xl p-4 shadow-lg bg-white dark:bg-gray-800 text-center">
        <h1 className="text-2xl md:text-3xl lg:text-4xl text-red-600 sm:text-blue-600 md:text-green-600 lg:text-indigo-600 hover:text-amber-600">
          Hello World
        </h1>
        <button className="p-2 mt-2 bg-blue-400 text-black rounded hover:bg-blue-300 hover:cursor-pointer">
          Read More
        </button>
      </div>
      <div className="bordered bordder rounded-2xl p-4 shadow-lg bg-white dark:bg-gray-800 text-center">
        <h1 className="text-2xl md:text-3xl lg:text-4xl text-red-600 sm:text-blue-600 md:text-green-600 lg:text-indigo-600 hover:text-amber-600">
          <SiamComponent data="Siam" carecter="Special" />
        </h1>
        <button className="p-2 mt-2 bg-blue-400 text-black rounded hover:bg-blue-300 hover:cursor-pointer">
          Read More
        </button>
      </div>

      <div className="bordered bordder rounded-2xl p-4 shadow-lg bg-white dark:bg-gray-800 text-center">
        <h1 className="text-2xl md:text-3xl lg:text-4xl text-red-600 sm:text-blue-600 md:text-green-600 lg:text-indigo-600 hover:text-amber-600">
          <SiamComponent data="Siam" carecter="Bad" />
        </h1>
        <button className="p-2 mt-2 bg-blue-400 text-black rounded hover:bg-blue-300 hover:cursor-pointer">
          Read More
        </button>
      </div>

      <div className="col-span-3 bordder rounded-2xl shadow-lg p-4 bg-white dark:bg-gray-800 text-center dark:text-white">
        <ChangeValue />
      </div>

      <FetchData />

      <Link to="/about">About Page</Link>
    </div>
  );
};

export default App;
