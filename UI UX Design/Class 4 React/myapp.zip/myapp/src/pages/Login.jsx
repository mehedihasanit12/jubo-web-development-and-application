import React from 'react';
import { Box } from '@mui/material';
import Button from '@mui/material/Button';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import Stack from '@mui/material/Stack';
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import Leftimage from "../assets/image.png";

export default function Login() {
  return (
    <Box
      display="flex"
      height="100vh"
      width="100%"
    >
      <Box
        flex={1.5}
        bgcolor="grey.100"
        overflow={'hidden'}
      >
       <img src={Leftimage} alt="" />
      </Box>
      <Box
        flex={1}
        bgcolor="grey.200"
        justifyContent={'center'}
        alignContent={'center'}

        sx={{
          background: 'linear-gradient(to bottom, #04202B, #1C1C1C)'
        }}
      >

        <Card elevation={0} sx={{minWidth: 275, backgroundColor: 'transparent'}}>

            <CardContent>
                <Typography sx={{ color: 'white' }} variant="h4" component="div">
                Login
                </Typography>

                 <Typography sx={{ color: 'white' }} variant="h6" component="div">
                Welcome to your Frydge portal
                </Typography>

                <Stack>
                    <TextField sx={{py:1, color: 'white',
                        '& .MuiOutlinedInput-root': {
              '& fieldset': {
                borderColor: 'white',
              },
              '&:hover fieldset': {
                borderColor: 'white',
              },
              '&.Mui-focused fieldset': {
                borderColor: 'white',
              },
            },
            '& .MuiInputLabel-root': {
              color: 'white',
            },
            '& .MuiOutlinedInput-input': {
              color: 'white',
            },
            }} size='medium' id="outlined-basic" label="Username" variant="outlined" />




                    <TextField sx={{py:1, color: 'white',
                        '& .MuiOutlinedInput-root': {
              '& fieldset': {
                borderColor: 'white',
              },
              '&:hover fieldset': {
                borderColor: 'white',
              },
              '&.Mui-focused fieldset': {
                borderColor: 'white',
              },
            },
            '& .MuiInputLabel-root': {
              color: 'white',
            },
            '& .MuiOutlinedInput-input': {
              color: 'white',
            },
                    }} id="outlined-basic" label="Password" variant="outlined" />
                </Stack>
            </CardContent>
            
            <CardActions>
                <Button sx={{mx:'auto', color: '#00B69D', borderRadius:25, width:'200px',borderColor:'#00B69D'}}  size="large" variant='outlined'>Login</Button>
            </CardActions>

        </Card>

        

        {/* <Box flex={0.5}>

          

        </Box> */}
        
      </Box>
    </Box>
  );
}
