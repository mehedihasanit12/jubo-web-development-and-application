import logo from './logo.svg';
import './App.css';
import Login from './pages/Login';
import { Box } from '@mui/material';
import Dashboard from './globalComponent/Dashboard';

function App() {
  return (
    <Box className="App">
      <Login/>
    </Box>
  );
}

export default App;
