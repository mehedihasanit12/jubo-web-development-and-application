@extends('admin.master')

@section('body')

    <h1>This is manage category page</h1>

@endsection
