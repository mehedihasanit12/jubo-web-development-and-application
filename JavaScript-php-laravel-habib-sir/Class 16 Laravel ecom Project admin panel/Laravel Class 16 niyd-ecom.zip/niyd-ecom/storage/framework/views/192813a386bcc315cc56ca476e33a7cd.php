<?php $__env->startSection('body'); ?>

    <h1>This is manage category page</h1>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed Software\Xammp\htdocs\niyd-ecom\resources\views/admin/category/index.blade.php ENDPATH**/ ?>