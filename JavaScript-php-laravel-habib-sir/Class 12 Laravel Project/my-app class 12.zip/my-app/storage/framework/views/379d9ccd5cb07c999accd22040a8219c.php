<?php $__env->startSection('title'); ?>
    Home Page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <section class="py-5 bg-info-subtle">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="card">
                        <img src="<?php echo e(asset($blog['image'])); ?>" alt=""/>
                        <div class="card-body">
                            <h1 class="card-title"><?php echo e($blog['title']); ?></h1>
                            <p>
                                <?php echo e($blog['description']); ?>

                            </p>
                            <a href="<?php echo e(route('detail', ['id' => $blog['id']])); ?>" class="btn btn-success">Read More</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed Software\Xammp\htdocs\my-app\resources\views/home.blade.php ENDPATH**/ ?>