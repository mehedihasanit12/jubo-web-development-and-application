<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>css/bootstrap.css">
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>css/style.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">

    <div class="container">

        <a href="<?php echo e(url('/')); ?>" class="navbar-brand">My APP</a>

        <ul class="navbar-nav ms-auto">
            <li class="nav-item"><a href="<?php echo e(route('home')); ?>" class="nav-link">Home</a></li>
            <li class="nav-item"><a href="<?php echo e(route('about')); ?>" class="nav-link">About</a></li>
            <li class="nav-item"><a href="<?php echo e(route('portfolio')); ?>" class="nav-link">Portfolio</a></li>
            <li class="nav-item"><a href="<?php echo e(route('gallery')); ?>" class="nav-link">Gallery</a></li>
            <li class="nav-item"><a href="<?php echo e(route('contact')); ?>" class="nav-link">Contact</a></li>
        </ul>
    </div>
</nav>


<?php echo $__env->yieldContent('body'); ?>



<script src="<?php echo e(asset('/')); ?>js/bootstrap.bundle.js"></script>
</body>
</html>

<?php /**PATH D:\Installed Software\Xammp\htdocs\my-app\resources\views/master.blade.php ENDPATH**/ ?>