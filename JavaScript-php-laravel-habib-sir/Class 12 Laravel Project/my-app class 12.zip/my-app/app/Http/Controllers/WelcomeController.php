<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Blog;

class WelcomeController extends Controller
{
    public $blogs, $blog, $result;

    public function index()
    {
        $this->blogs = Blog::getAllBlog();
        return view('home', ['blogs' => $this->blogs]);
    }

    public function about()
    {
        return view('about');
    }

    public function contact()
    {
        return view('contact');
    }

    public function portfolio()
    {
        return view('portfolio');
    }

    public function gallery()
    {
        return view('gallery');
    }

    public function detail($id)
    {
        $this->blog = Blog::getBlogById($id);
        return view('detail', ['blog' => $this->blog]);
    }

    public function makeFullName(Request $request)
    {
        $this->result = $request->first_name.' '.$request->last_name;
        return back()->with('result', $this->result);
    }

    public function myCalculator(Request $request)
    {
        return $request;
    }


}
