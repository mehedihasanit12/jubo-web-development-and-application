<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\WebsiteController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\CustomerAuthController;

Route::get('/', [WebsiteController::class, 'index'])->name('home');
Route::get('/product-category', [WebsiteController::class, 'category'])->name('product-category');
Route::get('/product-detail', [WebsiteController::class, 'product'])->name('product-detail');

//cart
Route::get('/cart/index', [CartController::class, 'index'])->name('cart.index');

//checkout
Route::get('/checkout/index', [CheckoutController::class, 'index'])->name('checkout.index');

//customer
Route::get('/customer/login-register', [CustomerAuthController::class, 'index'])->name('login-register');
