<?php $__env->startSection('body'); ?>

    <div class="row">
        <div class="col">
            <p class="text-center text-success"><?php echo e(session('message')); ?></p>
            <p class="text-center text-danger"><?php echo e(session('delete-message')); ?></p>
            <div class="card">
                <div class="card-datatable table-responsive pt-0">
                    <table class="table table-bordered text-center">
                        <thead>
                        <tr>
                            <th>SL</th>
                            <th>Category</th>
                            <th>Name</th>
                            <th>Description</th>
                            <th>Image</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                        </thead>

                        <tbody>

                        <?php $__currentLoopData = $sub_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e(isset($sub_category->category->name) ? $sub_category->category->name : ''); ?></td>
                                <td><?php echo e($sub_category->name); ?></td>
                                <td><?php echo e($sub_category->description); ?></td>
                                <td>
                                    <img src="<?php echo e(asset($sub_category->image)); ?>" width="70" height="70" alt="">
                                </td>
                                <td><?php echo e($sub_category->status == 1 ? 'Published' : 'Unpublished'); ?></td>
                                <td>
                                    <a href="<?php echo e(route('sub-category.edit', ['id' => $sub_category->id])); ?>" class="btn btn-success btn-sm">
                                        <i class="fa fa-edit"></i>
                                    </a>
                                    <a href="<?php echo e(route('sub-category.delete', ['id' => $sub_category->id])); ?>" class="btn btn-danger btn-sm" onclick=" return confirm('Are you sure to delete this!')">
                                        <i class="fa fa-trash"></i>
                                    </a>
                                </td>
                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed Software\Xammp\htdocs\niyd-ecom\resources\views/admin/sub-category/index.blade.php ENDPATH**/ ?>