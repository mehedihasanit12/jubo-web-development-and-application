<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    public static $student, $image, $imageName, $directory, $imageUrl;

    public static function newStudent($request)
    {
        self::$image        = $request->file('image');
        self::$imageName    = self::$image->getClientOriginalName();
        self::$directory    = 'img/uploads/';
        self::$image->move(self::$directory, self::$imageName);
        self::$imageUrl     = self::$directory.self::$imageName;

        self::$student = new Student();
        self::$student->name = $request->name;
        self::$student->email = $request->email;
        self::$student->mobile = $request->mobile;
        self::$student->image = self::$imageUrl;
        self::$student->address = $request->address;
        self::$student->save();
    }

    public static function updateStudent($request, $id)
    {
        self::$student = Student::find($id);

        if ($request->file('image'))
        {
            self::$image        = $request->file('image');
            self::$imageName    = self::$image->getClientOriginalName();
            self::$directory    = 'img/uploads/';
            self::$image->move(self::$directory, self::$imageName);
            self::$imageUrl     = self::$directory.self::$imageName;
        }
        else
        {
            self::$imageUrl = self::$student->image;
        }

        self::$student->name = $request->name;
        self::$student->email = $request->email;
        self::$student->mobile = $request->mobile;
        self::$student->image = self::$imageUrl;
        self::$student->address = $request->address;
        self::$student->save();
    }
}
