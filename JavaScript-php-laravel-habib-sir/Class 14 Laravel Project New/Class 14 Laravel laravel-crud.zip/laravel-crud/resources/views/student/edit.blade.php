@extends('master')

@section('title')
    Edit Student Page
@endsection


@section('body')

    <section class="py-5 bg-dark-subtle">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="card">
                        <div class="card-header">
                            Edit Student Form
                        </div>

                        <div class="card-body">
                            <p class="text-success">{{session('message')}}</p>
                            <form action="{{route('student.update', ['id' => $student->id])}}" method="POST" enctype="multipart/form-data">
                                @csrf
                                <div class="row mb-3">
                                    <label for="" class="col-md-3 fw-bold">Student Name</label>
                                    <div class="col-md-9">
                                        <input type="text" value="{{$student->name}}" class="form-control" name="name"/>
                                    </div>
                                </div>


                                <div class="row mb-3">
                                    <label for="" class="col-md-3 fw-bold">Student Email</label>
                                    <div class="col-md-9">
                                        <input type="email" value="{{$student->email}}" class="form-control" name="email"/>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <label for="" class="col-md-3 fw-bold">Student Mobile</label>
                                    <div class="col-md-9">
                                        <input type="number" value="{{$student->mobile}}" class="form-control" name="mobile"/>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <label for="" class="col-md-3 fw-bold">Student Image</label>
                                    <div class="col-md-9">
                                        <input type="file" class="form-control" name="image"/>
                                        <img src="{{asset($student->image)}}" class="mt-3" width="70" height="70">
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <label for="" class="col-md-3 fw-bold">Student Address</label>
                                    <div class="col-md-9">
                                        <textarea name="address" class="form-control">{{$student->address}}</textarea>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <label for="" class="col-md-3"></label>
                                    <div class="col-md-9">
                                        <input type="submit" class="btn btn-success" value="Update Student Info"/>
                                    </div>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

@endsection
