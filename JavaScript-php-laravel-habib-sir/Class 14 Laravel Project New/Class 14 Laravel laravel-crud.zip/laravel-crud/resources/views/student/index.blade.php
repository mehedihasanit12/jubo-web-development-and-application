@extends('master')

@section('title')
    Manage Student Page
@endsection


@section('body')

    <section class="py-5 bg-dark-subtle">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="card">
                        <p class="text-success">{{session('message')}}</p>
                        <div class="card-header">
                            All Student Info
                        </div>

                        <div class="card-body">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>SL NO</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Mobile</th>
                                        <th>Image</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>

                                <tbody>
                                   @foreach($students as $student)
                                    <tr>
                                        <td>{{$loop->iteration}}</td>
                                        <td>{{$student->name}}</td>
                                        <td>{{$student->email}}</td>
                                        <td>{{$student->mobile}}</td>
                                        <td><img src="{{asset($student->image)}}" width="70" height="70" alt=""></td>
                                        <td>
                                            <a href="{{route('student.edit',['id' => $student->id])}}" class="btn btn-success btn-sm">Edit</a>
                                            <a href="" class="btn btn-danger btn-sm">Delete</a>
                                        </td>
                                    </tr>
                                   @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

@endsection
