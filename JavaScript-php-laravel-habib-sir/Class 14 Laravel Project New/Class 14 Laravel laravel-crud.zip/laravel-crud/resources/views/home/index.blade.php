@extends('master')

@section('title')
    Home Page
@endsection

@section('body')

    <section class="py-5 bg-info-subtle">
        <div class="container">
            <div class="row">
                <div class="col">
                    <h1>Welcome To Laravel CRUD APP</h1>
                </div>
            </div>
        </div>
    </section>

@endsection
