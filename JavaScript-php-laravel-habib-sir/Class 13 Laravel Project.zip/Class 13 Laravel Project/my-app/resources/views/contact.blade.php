@extends('master')

@section('title')
    Contact Page
@endsection

@section('body')

    <section class="py-5 bg-primary-subtle">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h1>This is Contact page</h1>
                </div>

            </div>
        </div>
    </section>

@endsection
