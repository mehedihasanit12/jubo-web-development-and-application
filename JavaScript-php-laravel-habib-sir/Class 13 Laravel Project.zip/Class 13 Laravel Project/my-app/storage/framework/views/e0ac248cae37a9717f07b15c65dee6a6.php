<?php $__env->startSection('title'); ?>
    Gallery Page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <section class="py-5 bg-primary-subtle">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h1>This is Gallery page</h1>
                </div>

            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Installed Software\Xammp\htdocs\my-app\resources\views/gallery.blade.php ENDPATH**/ ?>