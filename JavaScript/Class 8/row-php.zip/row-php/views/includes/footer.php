<footer class="py-5 bg-dark" >
    <div class="container">
        <div class="row">
            <div class="col">
                <p class="text-white text-center mb-0">
                    Copyright@copyDiplomaWebDevelopmentBatchThree
                </p>
            </div>
        </div>
    </div>

</footer>


<script src="assets/js/bootstrap.bundle.js"></script>
</body>
</html>