<?php include "includes/header.php"; ?>

<section class="py-5 bg-info-subtle">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <h1>This is about page</h1>
            </div>
        </div>
    </div>
</section>

<?php include "includes/footer.php"; ?>
