<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Training Table</title>
    <link rel="stylesheet" href="\php-homework\training\views\style.css">
</head>
<body>
    <div class="container">
      <div class="table-div">
        <h1>Training Table</h1>

        <table border="1">

            <tr>
                <th>Name</th>
                <th style="width: 684px;">Description</th>
                <th>Price</th>
                <th>Starting Day</th>
            </tr>


            <?php foreach($training as $training) {?>

              <tr>
                <td><?php echo $training['name']; ?></td>
                <td><?php echo $training['description']; ?></td>
                <td><?php echo $training['price']; ?></td>
                <td><?php echo $training['start_date']; ?></td>
              </tr>

              <?php } ?>
           
        



        </table>
      </div>
    </div>
</body>
</html>