<?php


namespace App\classes;


class HelloWorld{

    public $training = [];


    public function index(){

        $this->training = [

            0=>[

                'name'          => 'Web Development',

                'description'   => 'Unlock the power of the web with our    comprehensive Web Development course. Whether you’re a beginner or looking to sharpen your skills, this course is designed to guide you through the fundamentals to advanced techniques of modern web development.',

                'price'         => '5000 TK',

                'start_date'    => '01.01.2025'
                
            ],


            1=>[

                'name'          => 'Hotel Management',

                'description'   => 'Unlock the power of the web with our    comprehensive Hotel Management course. Whether you’re a beginner or looking to sharpen your skills, this course is designed to guide you through the fundamentals to advanced techniques of modern Hotel Management.',

                'price'         => '5000 TK',

                'start_date'    => '01.01.2025'
                
            ],


            2=>[

                'name'          => 'ICT',

                'description'   => 'Unlock the power of the web with our    comprehensive ICT course. Whether you’re a beginner or looking to sharpen your skills, this course is designed to guide you through the fundamentals to advanced techniques of modern ICT.',

                'price'         => '5000 TK',

                'start_date'    => '01.01.2025'
                
            ],


            3=>[

                'name'          => 'Food Beverage',

                'description'   => 'Unlock the power of the web with our    comprehensive Food Beverage course. Whether you’re a beginner or looking to sharpen your skills, this course is designed to guide you through the fundamentals to advanced techniques of modern Food Beverage.',

                'price'         => '5000 TK',

                'start_date'    => '01.01.2025'
                
            ],

            4=>[

                'name'          => 'Graphics Design',

                'description'   => 'Unlock the power of the web with our    comprehensive Graphics Design course. Whether you’re a beginner or looking to sharpen your skills, this course is designed to guide you through the fundamentals to advanced techniques of modern Graphics Design.',

                'price'         => '5000 TK',

                'start_date'    => '01.01.2025'
                
            ],

            5=>[

                'name'          => 'Digital Marketing',

                'description'   => 'Unlock the power of the web with our    comprehensive Digital Marketing course. Whether you’re a beginner or looking to sharpen your skills, this course is designed to guide you through the fundamentals to advanced techniques of modern Digital Marketing.',

                'price'         => '5000 TK',

                'start_date'    => '01.01.2025'
                
            ]
            
        ];

        $training = $this->training;

        include "views/home.php";
    }


}