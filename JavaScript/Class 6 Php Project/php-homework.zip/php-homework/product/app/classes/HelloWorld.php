<?php



namespace App\classes;

class HelloWorld{

    public $product = [];


    public function index(){

        $this->product = [

            0=>[
                'name'              => 'Smartwatch',

                'description'       => 'A sleek and stylish smartwatch with health tracking, GPS, and water resistance up to 50 meters. Perfect for fitness enthusiasts and everyday wear.',

                'price'             => '$199'
            ],

            1=>[
                'name'              => 'Wireless Earbuds',

                'description'       => 'Compact and lightweight wireless earbuds with noise-canceling features, 8 hours of playtime, and a charging case. Ideal for music lovers on the go.',
                
                'price'             => '$59'
            ],

            2=>[
                'name'              => 'Laptop Backpack',

                'description'       => 'Durable and water-resistant laptop backpack with multiple compartments, suitable for laptops up to 15.6 inches. Comes with USB charging port support.',
                
                'price'             => '$49'
            ],

            3=>[
                'name'              => 'Electric Kettle',

                'description'       => 'Stainless steel electric kettle with a 1.7-liter capacity, fast boiling technology, and automatic shut-off for safety. Perfect for tea and coffee lovers.',
                
                'price'             => '$29'
            ],

            4=>[
                'name'              => 'Yoga Mat',

                'description'       => 'Non-slip, eco-friendly yoga mat with a comfortable 6mm thickness for all types of exercises, including yoga, Pilates, and meditation.',
                
                'price'             => '$25'
            ],
        ];

      $product = $this->product;
      include "views/home.php";

      
    }
}
