<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Table</title>
    <link rel="stylesheet" href="\php-homework\product\views\style.css">
</head>
<body>
    <div class="container">
      <div class="table-div">
        <h1>Product Table</h1>

        <table border="1">

            <tr>
                <th>Product Name</th>
                <th style="width: 684px;">Product Description</th>
                <th>Product Price</th>
            </tr>


            <?php foreach($product as $product) {?>

              <tr>
                <td><?php echo $product['name'] ?></td>
                <td><?php echo $product['description'] ?></td>
                <td><?php echo $product['price'] ?></td>
              </tr>

              <?php }?>


            
                
        



        </table>
      </div>
    </div>
</body>
</html>