<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Table</title>
    <link rel="stylesheet" href="\php-homework\student\views\style.css">
</head>
<body>
    <div class="container">
      <div class="table-div">
        <h1>Students Table</h1>

        <table border="1">

            <tr>
                <th>Roll</th>
                <th>Name</th>
                <th>Email</th>
                <th>Mobile</th>
            </tr>


            
                <?php foreach($students as $student) { ?>
            <tr>
                <td><?php echo $student['roll'];  ?></td>
                <td><?php echo $student['name'];  ?></td>
                <td><?php echo $student['email'];  ?></td>
                <td><?php echo $student['mobile'];  ?></td>
            </tr>
                <?php } ?>
        



        </table>
      </div>
    </div>
</body>
</html>