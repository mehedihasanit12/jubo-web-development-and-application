<?php


namespace App\classes;

class HelloWorld{

    public $students=[];


    public function index(){
        $this->students = [
            0=>[
                'roll'      => '1',
                'name'      => 'Shakib',
                'email'     => 'shakib@gmail.com',
                'mobile'    => '0154353434'
            ],

            1=>[
                'roll'      => '2',
                'name'      => 'Rakib',
                'email'     => 'rakib@gmail.com',
                'mobile'    => '0133433434'
            ],

            2=>[
                'roll'      => '3',
                'name'      => 'Akib',
                'email'     => 'akib@gmail.com',
                'mobile'    => '0195675434'
            ],

            3=>[
                'roll'      => '4',
                'name'      => 'Musfiq',
                'email'     => 'musfiq@gmail.com',
                'mobile'    => '0134743932'
            ],

            4=>[
                'roll'      => '4',
                'name'      => 'Sadiq',
                'email'     => 'sadiq@gmail.com',
                'mobile'    => '0134743932'
            ]
        ];

        $students = $this->students;
        include "views/home.php";

        

        // foreach($this->students as $student){
        //     echo $student['name'];
        // }


    }

    


}